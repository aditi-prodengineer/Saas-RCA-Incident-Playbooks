# RCA: <short incident title>

- **Date:**
- **Severity:** (S1 critical / S2 high / S3 medium / S4 low)
- **Status:** (Investigating / Mitigated / Resolved)
- **Owner:**

## 1. Summary
Two or three sentences in plain language: what broke, for whom, and for how long.

## 2. Impact
- Who was affected (number of accounts, type of customer)
- What they could not do
- Any data at risk

## 3. Timeline
| Time (UTC) | Event |
|---|---|
| | First symptom reported or detected |
| | Investigation started |
| | Root cause identified |
| | Fix deployed |
| | Verified resolved |

## 4. Detection
How did we find out (alert, customer report, monitoring)? Could we have found out sooner?

## 5. Investigation
The evidence, step by step: logs, request and response samples, queries, what was ruled out and why.

## 6. Root cause
The underlying cause, not just the trigger. Use the "five whys" if it helps.

## 7. Resolution
What was done to fix it, and who did it.

## 8. Verification
How we confirmed that the fix worked and that nothing else broke.

## 9. Prevention
| Action | Owner | Due |
|---|---|---|
| | | |

## 10. Customer communication
What was communicated, when, and in what words.

## 11. Lessons learned
What went well, what did not, and what we will change.
