-- Example triage queries for a FICTIONAL incident database.
-- Adapt table and column names to your own schema.

-- Fictional schema:
--   webhook_events(id, endpoint_id, event_type, status_code, attempt, created_at)
--   api_requests(id, client_id, path, status_code, latency_ms, created_at)

-- 1. Failed webhook deliveries per endpoint per hour (playbook 01)
SELECT
    endpoint_id,
    DATE_TRUNC('hour', created_at) AS hour,
    COUNT(*) AS total_attempts,
    SUM(CASE WHEN status_code >= 500 THEN 1 ELSE 0 END) AS server_errors
FROM webhook_events
WHERE created_at >= NOW() - INTERVAL '24 hours'
GROUP BY endpoint_id, DATE_TRUNC('hour', created_at)
HAVING SUM(CASE WHEN status_code >= 500 THEN 1 ELSE 0 END) > 0
ORDER BY hour, server_errors DESC;

-- 2. Events that exhausted their retries and still need a replay
SELECT id, endpoint_id, event_type, MAX(attempt) AS last_attempt
FROM webhook_events
GROUP BY id, endpoint_id, event_type
HAVING MAX(attempt) >= 6 AND MAX(status_code) >= 400;

-- 3. Error rate by status code for one client (playbooks 02 and 03)
SELECT
    client_id,
    status_code,
    COUNT(*) AS requests,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY client_id), 1) AS percent
FROM api_requests
WHERE created_at >= NOW() - INTERVAL '24 hours'
  AND client_id = 'client_123'
GROUP BY client_id, status_code
ORDER BY requests DESC;

-- 4. Slowest endpoints over the last hour
SELECT path, COUNT(*) AS requests, ROUND(AVG(latency_ms)) AS avg_ms, MAX(latency_ms) AS max_ms
FROM api_requests
WHERE created_at >= NOW() - INTERVAL '1 hour'
GROUP BY path
ORDER BY avg_ms DESC
LIMIT 10;

-- 5. Duplicate events, to check that receivers are idempotent
SELECT id, COUNT(*) AS times_delivered
FROM webhook_events
WHERE status_code BETWEEN 200 AND 299
GROUP BY id
HAVING COUNT(*) > 1;
