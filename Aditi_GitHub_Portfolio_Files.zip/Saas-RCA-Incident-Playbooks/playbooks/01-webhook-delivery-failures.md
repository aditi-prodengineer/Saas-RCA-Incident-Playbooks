# RCA: Webhook deliveries failing after a customer endpoint change

> Fictional scenario for practice. Company, customer and data are invented.

- **Severity:** S2 (high)
- **Status:** Resolved

## 1. Summary
A fictional customer stopped receiving "invoice.paid" webhooks from the platform. Their finance system showed invoices as unpaid even though payments had cleared. The cause was a change on the customer's side that made their endpoint return `502` responses, combined with a retry window that expired before the endpoint recovered.

## 2. Impact
- 1 customer account, around 340 events not delivered over 6 hours
- Invoices marked unpaid in the customer's system, which triggered reminder emails to their own clients
- No data lost on our side, because every event was stored

## 3. Timeline
| Time (UTC) | Event |
|---|---|
| 08:10 | Customer deploys a new load balancer in front of their webhook endpoint |
| 08:15 | Deliveries begin returning `502 Bad Gateway` |
| 08:15 to 14:15 | Retries follow the platform schedule, then events move to "failed" |
| 14:40 | Customer reports unpaid invoices |
| 15:05 | Investigation confirms failed deliveries for one endpoint |
| 15:50 | Customer fixes the load balancer routing |
| 16:20 | Failed events replayed, all 340 delivered |

## 4. Detection
Found through a customer report. There was no alert on a high failure rate for a single endpoint, so detection was roughly 6 hours late.

## 5. Investigation
1. Checked the delivery log for the endpoint: all attempts since 08:15 returned `502`, none before.
2. Compared with other customers: no failures, so the platform itself was healthy.
3. Sent a test request to the endpoint with `curl -i`, which also returned `502` and showed the new load balancer in the response headers.
4. Confirmed the retry schedule had been exhausted, so events were in a failed state rather than pending.

Triage query used (see `sql/triage-queries.sql`): failed deliveries per endpoint per hour.

## 6. Root cause
The customer's new load balancer did not route the webhook path to their application. Our system behaved as designed, but the retry window (6 hours) was shorter than the outage, and nothing alerted us when one endpoint failed repeatedly.

## 7. Resolution
The customer corrected the routing. We replayed the 340 failed events in order.

## 8. Verification
- Replayed events returned `200`
- Event counts on both sides matched
- Customer confirmed invoices showed as paid

## 9. Prevention
| Action | Owner | Due |
|---|---|---|
| Alert when one endpoint exceeds a failure-rate threshold | Platform team | Next sprint |
| Email customers automatically when their endpoint fails repeatedly | Product | Next quarter |
| Add a "replay failed events" step to the troubleshooting guide | Technical engineer | This week |
| Make receivers idempotent, using the event ID, so replays are safe | Customer, with our guidance | Next sprint |

## 10. Customer communication
Acknowledged the report within 30 minutes, shared the cause and the replay plan before replaying, and sent a short written summary afterwards.

## 11. Lessons learned
- Alert on patterns per endpoint, not only on platform-wide errors
- Replays must be safe, so idempotency keys matter
