# RCA: Sudden 401 Unauthorized errors on a working integration

> Fictional scenario for practice. Company, customer and data are invented.

- **Severity:** S3 (medium)
- **Status:** Resolved

## 1. Summary
A fictional integration that had worked for months began returning `401 Unauthorized` on every call. Access tokens were expiring, and the refresh step was failing because the client stored an old refresh token after the provider started rotating them.

## 2. Impact
- 1 integration paused, no data synchronised for about 20 hours
- No data loss, the sync resumed from the last checkpoint

## 3. Timeline
| Time (UTC) | Event |
|---|---|
| Day 1, 09:00 | Provider enables refresh token rotation for the tenant |
| Day 1, 10:00 | First access token expires, refresh succeeds, but the new refresh token is not saved |
| Day 1, 11:00 | Next refresh uses the old token and fails with `invalid_grant` |
| Day 2, 05:00 | Customer reports the sync has stopped |
| Day 2, 05:40 | Cause identified from the auth logs |
| Day 2, 06:30 | Customer re-authorises, sync resumes |

## 4. Detection
Customer report. A monitor on authentication failures per integration would have caught it within an hour.

## 5. Investigation
1. Reproduced the error with Postman: a call with the stored token returned `401` with a "token expired" message.
2. Attempted a refresh with the stored refresh token and got `400 invalid_grant`.
3. Checked the provider's release notes and found refresh token rotation had been enabled.
4. Reviewed the connector's token storage and confirmed it only saved the access token after a refresh.

## 6. Root cause
The integration assumed a refresh token never changes. Once the provider rotated tokens, every refresh invalidated the stored one.

## 7. Resolution
The customer re-authorised the connection to issue new tokens, and the connector was changed to store the new refresh token on every refresh.

## 8. Verification
- Several refresh cycles completed without errors
- Sync resumed and record counts matched

## 9. Prevention
| Action | Owner | Due |
|---|---|---|
| Always persist the latest refresh token after each refresh | Engineering | Next release |
| Alert on repeated `invalid_grant` errors per integration | Platform team | Next sprint |
| Add a "401 versus 403" decision guide to the runbook | Technical engineer | This week |

## 10. Customer communication
Explained in plain language that the provider had changed how tokens work, gave clear re-authorisation steps, and confirmed once the sync caught up.

## 11. Lessons learned
- `401` means "who are you?" and `403` means "you may not do this". Checking which one you get saves time.
- Read the provider's changelog early when a stable integration suddenly breaks.
