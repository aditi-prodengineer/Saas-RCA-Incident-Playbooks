# RCA: 429 Too Many Requests during a bulk data sync

> Fictional scenario for practice. Company, customer and data are invented.

- **Severity:** S3 (medium)
- **Status:** Resolved

## 1. Summary
During an initial bulk sync of 200,000 records, a fictional integration hit the API rate limit and kept failing with `429 Too Many Requests`. The client retried immediately and without a pause, which kept it permanently over the limit.

## 2. Impact
- The first sync for one customer took about 3 days instead of a few hours
- Other customers were not affected

## 3. Timeline
| Time (UTC) | Event |
|---|---|
| 10:00 | Bulk sync starts |
| 10:12 | First `429` responses appear |
| 10:12 onwards | Client retries instantly, error rate climbs above 80% |
| Day 2 | Customer reports slow progress |
| Day 2, 14:00 | Cause identified |
| Day 3, 09:00 | Fixed client restarts the sync, finishes in 4 hours |

## 4. Detection
Customer report about slow progress. The error rate was visible in the logs from the first hour.

## 5. Investigation
1. Counted response codes for the integration over time (see `sql/triage-queries.sql`): `429` rose from 0% to more than 80%.
2. Inspected the response headers, which included `Retry-After` values that the client ignored.
3. Confirmed the client sent requests in parallel with no limit on concurrency.
4. Checked pagination: the client re-requested entire pages after a failure instead of resuming.

## 6. Root cause
No backoff and no respect for `Retry-After`, plus unlimited parallel requests. Failed requests were retried at once, which made the problem worse.

## 7. Resolution
- Honour `Retry-After` and use exponential backoff with jitter
- Limit concurrency to a safe value
- Resume pagination from the last successful cursor

## 8. Verification
- `429` rate dropped below 1%
- Record counts matched at the end of the sync

## 9. Prevention
| Action | Owner | Due |
|---|---|---|
| Add backoff and concurrency limits to the connector template | Engineering | Next release |
| Document rate limits and `Retry-After` handling for customers | Technical engineer | This week |
| Offer a bulk or batch endpoint for large first syncs | Product | Next quarter |

## 10. Customer communication
Shared the rate limit numbers, the plan to resume safely, and an estimated finish time, then confirmed when the sync completed.

## 11. Lessons learned
- Retrying instantly turns a short throttle into a long outage
- Large first syncs need a different approach from day-to-day traffic
