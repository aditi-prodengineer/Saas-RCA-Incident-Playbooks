# Hi, I'm Aditi

**Technical Engineer | SaaS, APIs and Incident Analysis**

I have 4+ years of experience in enterprise software, currently working on a cloud-based B2B SaaS product. My day-to-day work is troubleshooting integrations and APIs, finding root causes with engineering teams, and documenting what we learn so it can be reused. I am planning to relocate to Germany and I am open to technical engineer roles in Berlin, Munich, Frankfurt or remote within Germany.

## What I work with

- **APIs and integrations:** REST APIs, Postman, JSON payloads, webhooks, HTTP status code triage
- **Troubleshooting:** root cause analysis, log analysis, SQL queries, incident write-ups
- **Cloud and tools:** AWS, Google Cloud, Git, JIRA, Confluence, ServiceNow, Zendesk, Salesforce
- **Systems:** Linux, SSH, IP networking and protocols

## Portfolio

- [SaaS RCA Incident Playbooks](https://github.com/aditi-prodengineer/Saas-RCA-Incident-Playbooks): fictional, anonymised root cause analyses, SQL triage queries and a Postman collection that I wrote to practise and share my troubleshooting approach.

## Languages

English (C1) | German (A1, learning) | French (A1 and A2, certified)

## Contact

[LinkedIn](https://www.linkedin.com/in/aditi-sonawane-b7b785185)
